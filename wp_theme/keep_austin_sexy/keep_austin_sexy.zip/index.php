<?php
get_header();
?>

<main class="main">
            <section class="banner_wraper container">
                <div class="banner_img">
                    <img src="<?php the_field('banner_img'); ?>" alt="Keep Austin Sexy — Personal freedom fitness apparel">
                </div>
                <div class="banner_text_block">
                    <h1 class="banner_title text_32"><?php the_field('banner_title'); ?> <span class="banner_title_second_part text_24"><?php the_field('banner_title_second_part'); ?></span></h1>
                    <p class="banner_text text_16"><?php the_field('banner_text'); ?></p>
                    <form class="banner_contact_form" action="#">
                        <input class="input_mail" type="mail" placeholder="e-mail">
                        <button class="button text_18">Sign up</button>
                    </form>
                </div>
            </section>
            <section class="philosophy container" id="philosophy">
                <h2 class="philosophy_title"><?php the_field('philosophy_title'); ?></h2>
                <div class="philosophy_content">
                    <div class="parent_img philosophy_content_img">
                        <img src="<?php the_field('philosophy_content_img'); ?>" alt="Our mission">
                    </div>
                    <div class="philosophy_post philosophy_post_odd">
                        <div class="philosophy_post_text philosophy_post_text_odd">
                            <h3>We didn't make Austin sexy, we just help keep it that way!</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Libero libero commodo odio nisi, integer morbi vitae tellus justo. Neque, purus diam sit duis nam. Dolor neque, eu quis viverra ornare cras. Lacus viverra sed sagittis, purus non malesuada adipiscing urna. <br>
                                <br>
                                Congue tincidunt vel aliquet massa, posuere. Pellentesque tristique consectetur odio pellentesque nunc dolor sapien. Nisl, in etiam hendrerit tortor eget blandit. </p>
                        </div>
                        <div class="philosophy_img philosophy_img_odd">
                            <img src="<?php echo bloginfo('template_url');  ?>/assets/images/our_mission_section_1.jpg" alt="We didn't make Austin sexy, we just help keep it that way!">
                        </div>
                    </div>
                    <div class="philosophy_post philosophy_post_even">
                        <div class="philosophy_post_text philosophy_post_text_even">
                            <h3>The Softest Fabric Meets the Coolest City</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Libero libero commodo odio nisi, integer morbi vitae tellus justo. Neque, purus diam sit duis nam. Dolor neque, eu quis viverra ornare cras. Lacus viverra sed sagittis, purus non malesuada adipiscing urna. <br><br>
                                Congue tincidunt vel aliquet massa, posuere. Pellentesque tristique consectetur odio pellentesque nunc dolor sapien. Nisl, in etiam hendrerit tortor eget blandit. </p>
                        </div>
                        <div class="philosophy_img philosophy_img_even">
                            <img src="<?php echo bloginfo('template_url');  ?>/assets/images/our_mission_section_2.jpg" alt="Freedom and ease in every movement">
                        </div>
                    </div>
                </div>
            </section>

            <section class="contact_form_middle_wraper contact_form_wraper">
                <div class="contact_form_middle_img"></div>
                <div class="empty">
                </div>
                <div class="absolute">
                    <div class="contact_form_middle_wraper_text contact_form_wraper_text">
                        <h2 class="contact_form_middle_wraper_text_title contact_form_wraper_text_title"><?php the_field('contact_form_middle_title'); ?></h2>
                        <p class="contact_form_middle_wraper_text_desc"><?php the_field('contact_form_middle_desc'); ?></p>
                        <form class="contact_form contact_form_middle_form" action="#">
                            <input class="input_mail contact_form_mail dt_form_mail" type="mail" placeholder="e-mail">
                            <button class="button">Sign up</button>
                        </form>
                    </div>
                </div>
            </section>

            <section class="about_us container" id="about_us">
                <h2 class="about_us_title"><?php the_field('about_us_title'); ?></h2>
                <div class="about_us_post_wraper">
                    <div class="about_us_post about_us_post_odd">
                        <div class="about_us_text_block">
                            <h3 class="about_us_text_title">Fashion as unique as Austin</h3>
                            <p class="about_us_desc">Lorem ipsum dolor sit amet, consectetur as, purus non malesuada adipiscing urna. <br><br>
                                Congue tincidunt vel aliquet massa, posuere. Pellentesque tristique consectetur odio pellentesque nunc dolor sapien. Nisl, in etiam hendrerit tortor eget blandit. </p>           
                        </div>
                        <div class="about_us_post_img parent_img">
                            <img src="<?php echo bloginfo('template_url');  ?>/assets/images/about_kas_section_1.jpg" alt="Fashion as unique as Austin">                        
                        </div>
                    </div>
                    <div class="about_us_post about_us_post_even">
                        <div class="about_us_text_block about_us_text_block_even">
                            <h3 class="about_us_text_title">Fitness Apparel - Built to last</h3>
                            <p class="about_us_desc">Lorem ipsum dolor sit amet, consectetur as, purus non malesuada adipiscing urna. <br><br>
                                Congue tincidunt vel aliquet massa, posuere. Pellentesque tristique consectetur odio pellentesque nunc dolor sapien. Nisl, in etiam hendrerit tortor eget blandit. </p>           
                        </div>
                        <div class="about_us_post_img about_us_post_img_even parent_img">
                            <img src="<?php echo bloginfo('template_url');  ?>/assets/images/about_kas_section_2.jpg" alt="Fitness Apparel - Built to last">                        
                        </div>
                    </div>
                </div>
            </section>
            <section class="showcase container" id="showcase">
                <h2 class="showcase_title"><?php the_field('showcase_title'); ?></h2>
                <div class="showcase_post">
                    <div class="showcase_post_text">
                        <h3 class="showcase_post_text_title"><?php the_field('showcase_post_title'); ?></h3>
                        <p class="showcase_post_text_descr"><?php the_field('showcase_post_descr'); ?></p>
                    </div>
                    <div id="myCarousel" class="showcase_post_slider carousel w-10/12 max-w-5xl mx-auto">
                        <div class="showcase_post_text_desktop">
                            <h3 class="showcase_post_text_title"><?php the_field('showcase_post_title'); ?>s</h3>
                            <p class="showcase_post_text_descr"><?php the_field('showcase_post_descr'); ?></p>
                        </div>
                        <div class="carousel__slide carousel__slide_1">
                            <img src="<?php echo bloginfo('template_url');  ?>/assets/images/popular_gallery_1.jpg" />
                        </div>
                        <div class="carousel__slide carousel__slide_2">
                            <img src="<?php echo bloginfo('template_url');  ?>/assets/images/popular_gallery_2.jpg" />
                        </div>
                        <div class="carousel__slide carousel__slide_3">
                            <img src="<?php echo bloginfo('template_url');  ?>/assets/images/popular_gallery_3.jpg" />
                        </div>
                        <div class="carousel__slide carousel__slide_4">
                            <img src="<?php echo bloginfo('template_url');  ?>/assets/images/popular_gallery_4.jpg" />
                        </div>
                    </div>
                </div>
            </section>

            <section class="contact_form_bottom_wraper contact_form_wraper">
                <div class="contact_form_bottom_img"></div>
                <div class="">
                </div>
                <div class="absolute">
                    <div class="contact_form_bottom_wraper_text contact_form_wraper_text">
                        <h2 class="contact_form_bottom_wraper_text_title contact_form_wraper_text_title"><?php the_field('contact_form_bottom_title'); ?></h2>
                        <p class="contact_form_bottom_wraper_text_desc"><?php the_field('contact_form_bottom_desc'); ?></p>
                        <form class="contact_form" action="#">
                            <input class="input_mail contact_form_mail dt_form_mail" type="mail" placeholder="e-mail">
                            <button class="button">Sign up</button>
                        </form>
                    </div>
                </div>
            </section>
        </main>

<?php
get_footer();
?>
